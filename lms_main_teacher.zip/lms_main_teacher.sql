-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 03, 2014 at 11:12 AM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `final_teacher`
--

-- --------------------------------------------------------

--
-- Table structure for table `lms_main_teacher`
--

CREATE TABLE IF NOT EXISTS `lms_main_teacher` (
  `TEACHER_ID` varchar(100) NOT NULL,
  `NAME` varchar(100) NOT NULL,
  `USERNAME` varchar(100) NOT NULL,
  `PASSWORD` varchar(100) NOT NULL,
  `SUBJECT` varchar(100) NOT NULL,
  PRIMARY KEY (`TEACHER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lms_main_teacher`
--

INSERT INTO `lms_main_teacher` (`TEACHER_ID`, `NAME`, `USERNAME`, `PASSWORD`, `SUBJECT`) VALUES
('12345', 'teacher1', 'teacher', 'teacher', 'teacher'),
('123456', 'fred', 'dswd', 're', 'ere'),
('cef', 'fred', 'fedf', 're', 'ere'),
('er', 'ere', 'rer', 'ere', 'refr'),
('rterg', 'dxs', 'fedf', 're', 'ere'),
('ryr', 'rgr', 'yry', 'rhr', 'yhtry'),
('scxs', 'ere', 'fedf', 'ere', 'fdf'),
('vvcd', 'fred', 'ere', 'ere', 'fdf');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
