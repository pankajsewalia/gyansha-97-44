-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 03, 2014 at 11:12 AM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `final_teacher`
--

-- --------------------------------------------------------

--
-- Table structure for table `lms_teacher_query`
--

CREATE TABLE IF NOT EXISTS `lms_teacher_query` (
  `QUERY_ID` int(100) NOT NULL AUTO_INCREMENT,
  `ACK_QUERY` int(1) NOT NULL DEFAULT '0',
  `TEACHER_ID` varchar(100) NOT NULL,
  `QUERY_STRING` varchar(100) NOT NULL,
  `QUERY_TIMESTAMP` varchar(100) NOT NULL,
  PRIMARY KEY (`QUERY_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `lms_teacher_query`
--

INSERT INTO `lms_teacher_query` (`QUERY_ID`, `ACK_QUERY`, `TEACHER_ID`, `QUERY_STRING`, `QUERY_TIMESTAMP`) VALUES
(24, 0, '12345', ',j', '2014-05-26 21:04:40.403'),
(25, 0, '12345', 'fd', '2014-05-26 21:04:44.329'),
(26, 0, '12345', 'fd', '2014-05-26 21:04:46.208'),
(27, 0, '12345', 'fd', '2014-05-26 21:04:48.574'),
(28, 0, '12345', 'check for scxs', '2014-05-26 21:46:26.374'),
(29, 0, '12345', 'ewed', '2014-05-26 21:46:34.414'),
(30, 0, '12345', 'fgsegf', '2014-05-27 22:35:27.123');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
