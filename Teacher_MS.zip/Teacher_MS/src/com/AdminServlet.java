/**
 * Author Name					Date							Discription
 * ---------------------------------------------------------------------------------------------------------------
 * Pankaj Sewalia				23-May-2014						Controller Servlet for admin module of LMS
 * ---------------------------------------------------------------------------------------------------------------
 */
package com;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
// Extend HttpServlet class
public class AdminServlet extends HttpServlet { 
  @Override
  public void init() throws ServletException{ /* Do required initialization*/ } 
  ArrayList<String> list =null;
  @Override
  public void doPost(HttpServletRequest request,HttpServletResponse response)
            throws ServletException, IOException {
      String jMessage = null; 
      response.setContentType("text/html"); 
      //PrintWriter out = response.getWriter();
      String jEventName = request.getParameter("jEventName");
	  System.out.println("jEventName: " + jEventName);
      if(jEventName != null && jEventName.equalsIgnoreCase("AdminLogin")){//add code for AdminLogin
          String username = request.getParameter("user_id");
          String password = request.getParameter("pass");
          list = new ArrayList<String>();
          list.add(0,username);
          list.add(1,password);
          if(isAllowed()){request.setAttribute("jEventName", jEventName);request.getRequestDispatcher("AdminMain.jsp").forward(request, response);}else
    	  request.getRequestDispatcher("AdminLogin.jsp").forward(request, response);
      }else if(jEventName != null && jEventName.equalsIgnoreCase("T_Create")){//add code for T_Create
          String teacherName = request.getParameter("t_name");
          String username = request.getParameter("user");
          String password = request.getParameter("pwd");
          String subject = request.getParameter("subject");
          String teacherId = request.getParameter("t_id");  
          list = new ArrayList<String>();
          list.add(0, teacherName);
          list.add(1, username);
          list.add(2, password);
          list.add(3, subject);
          list.add(4, teacherId);
          if(checkTeacherId(teacherId)){
        	  jMessage = "provided Teacher Id is already exist...please choose another teacher Id";  request.setAttribute("jEventName", jEventName); request.setAttribute("jMessage", jMessage)
        	  ;request.getRequestDispatcher("T_Create.jsp").forward(request, response); }else{ if(sendTeacher()){ jMessage = "New Teacher Successfully created"; request.setAttribute("jEventName", jEventName);
        	  request.setAttribute("jMessage", jMessage); request.getRequestDispatcher("Success.jsp").forward(request, response);}
          }
      }else if(jEventName != null && jEventName.equalsIgnoreCase("T_Query")){//add code for T_Query
          String teacherId = request.getParameter("teacher_id");
          String teacherQuery = request.getParameter("teacher_query"); 
          //get earlier queries from the same teacher id starts
          ArrayList<String> queryArrList = new ArrayList<String>();
    	  ArrayList<String> jTeacherInfo = new ArrayList<String>();
          queryArrList = getQueries(teacherId);
          jTeacherInfo = getTeacherById(teacherId);
          //get earlier queries from the same teacher id starts
          jMessage = "Teacher Id you provided is not available"; 
          //System.out.println("teacherId:  "+teacherId); 
          if(checkTeacherId(teacherId)){
              list =  new ArrayList<String>();
              list.add(0, teacherId);
              list.add(1, teacherQuery);   
              //System.out.println("list:  "+list); 
              if(sendQuery()){
            	  request.setAttribute("jTeacherInfo", jTeacherInfo);request.setAttribute("jQueryArrList", queryArrList);request.setAttribute("jEventName", jEventName);request.setAttribute(
            			  "jTeacherId", teacherId); request.getRequestDispatcher("Acknowledge.jsp").forward(request, response) ;}
          }else{request.setAttribute("jEventName", jEventName);request.setAttribute("jMessage", jMessage);request.getRequestDispatcher("T_Query.jsp").forward(request, response);}
      }else if(jEventName != null && jEventName.equalsIgnoreCase("T_Audit")){//add code for T_Audit
      }else if(jEventName != null && jEventName.equalsIgnoreCase("S_profile")){//add code for S_profile
      }
   } 
  @Override
  public void destroy(){ /* do nothing.*/ }  
  private Connection getConnection(){
	  Connection con= null;
	  try{
		  Class.forName("com.mysql.jdbc.Driver");
		  con= DriverManager.getConnection("jdbc:mysql://localhost/Final_Teacher","root","");
	  	} catch(Exception e){
		  System.out.println(e);
		  e.printStackTrace();
	  	}
	  return con;
  }
  private void closeConnection(Connection con){
	  try{
		  if(con != null){
			con.close();
		  }
	  }catch(SQLException sqe){
		  System.out.println(sqe);
		  sqe.printStackTrace();
	  }
  }
  private boolean isAllowed(){
	  //System.out.println("username :  "+username +"  password :  "+password);	 
	  return true;
  }
  private boolean sendTeacher(){	
	  //System.out.println("list :  "+list);
	Connection con = null;
	int value = -1;
	try{
		con = getConnection(); 
		String sql = "INSERT INTO lms_main_teacher VALUES(?,?,?,?,?)";
		PreparedStatement ps = con.prepareStatement(sql);
		if(!list.isEmpty()){
			ps.setString(1, list.get(4));
			ps.setString(2, list.get(0));
			ps.setString(3, list.get(1));
			ps.setString(4, list.get(2));
			ps.setString(5, list.get(3));	
			value = ps.executeUpdate();				
		}
	}catch(SQLException sqe){
		System.out.println(sqe);sqe.printStackTrace();
	}finally{closeConnection(con);}
	if(value != -1){return true;}else return false;
  }
  private boolean sendQuery(){	
    //System.out.println("list :  "+list);
	Connection con = null;
	int value = -1;
	try{
        //changing timestamp zone starts 
			//java.util.Date date = new java.util.Date();				    
		    Time time = new Time(19800000);
		    Calendar c = Calendar.getInstance();		     
		    Timestamp timestamp = new Timestamp( c.getTimeInMillis() + time.getTime() );		        
		 	//java.util.Date newDate = new java.util.Date(timestamp.getTime() );
		 //changing timestamp zone ends 
		con = getConnection(); 
		String sql = "INSERT INTO lms_teacher_query(TEACHER_ID, QUERY_STRING, QUERY_TIMESTAMP) VALUES(?,?,?)";
		PreparedStatement ps = con.prepareStatement(sql);
		if(!list.isEmpty()){
			ps.setString(1, list.get(0));
			ps.setString(2, list.get(1));
			ps.setString(3, timestamp.toString());	
			value = ps.executeUpdate();				
		}
	}catch(SQLException sqe){
		System.out.println(sqe);
		sqe.printStackTrace();
	}finally{closeConnection(con);}
	if(value != -1)return true;else return false;
  }
  private boolean checkTeacherId(String teacherId){
	Connection con = null;
	ResultSet rs = null;
	int countTID = 0;
	try{
		con = getConnection(); 
		String sql = "SELECT COUNT(1) FROM lms_main_teacher WHERE TEACHER_ID = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, teacherId);
		rs = ps.executeQuery();
		while(rs.next()){
			//System.out.println("countTID:  "+countTID);
			countTID = rs.getInt(1);
		}
	}catch(SQLException sqe){
		System.out.println(sqe);
		sqe.printStackTrace();
	}finally{closeConnection(con);}
	if(countTID != 0)return true;else return false;
  }
  private ArrayList<String> getQueries(String teacherId){
	ArrayList<String> aList = new ArrayList<String>();	
	Connection con = null;
	ResultSet rs = null;
	try{
		con = getConnection(); 
		String sql = "SELECT QUERY_STRING, ACK_QUERY FROM lms_teacher_query WHERE TEACHER_ID = ? ORDER BY QUERY_TIMESTAMP DESC";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, teacherId);
		rs = ps.executeQuery();
		int i=0;
		while(rs.next()){
			aList.add(i,rs.getInt(2)+"|"+rs.getString(1));
			i++;
		}		
	}catch(SQLException sqe){
		System.out.println(sqe);
		sqe.printStackTrace();
	}finally{closeConnection(con);}	
	return aList;
  }
  private ArrayList<String> getTeacherById(String teacherId){
	  ArrayList<String> aList = new ArrayList<String>();
		Connection con = null;
		ResultSet rs = null;
		try{
			con = getConnection(); 
			String sql = "SELECT NAME, USERNAME, SUBJECT FROM lms_main_teacher WHERE TEACHER_ID = ? ";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, teacherId);
			rs = ps.executeQuery();
			while(rs.next()){
				aList.add(0,rs.getString(1));
				aList.add(1,rs.getString(2));
				aList.add(2,rs.getString(3));
			}		
		}catch(SQLException sqe){
			System.out.println(sqe);
			sqe.printStackTrace();
		}finally{closeConnection(con);}	
		return aList;
	  
  }
//end of the controller
}